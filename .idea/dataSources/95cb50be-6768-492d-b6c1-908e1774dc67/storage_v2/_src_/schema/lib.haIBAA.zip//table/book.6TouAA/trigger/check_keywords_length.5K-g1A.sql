create definer = root@localhost trigger check_keywords_length
    before insert
    on book
    for each row
BEGIN
    DECLARE oneword VARCHAR(255);
    DECLARE remaining_keywords TEXT;
    DECLARE keyword_end INT;

    -- 初始化要检测的字符串
    SET remaining_keywords = NEW.keyword;

    -- 循环处理 `keywords` 字段中的每个关键字
    WHILE LENGTH(remaining_keywords) > 0 DO
            -- 找到第一个 '、' 的位置
            SET keyword_end = LOCATE('、', remaining_keywords);

            -- 如果没有找到 '、'，取整段字符串作为最后一个关键字
            IF keyword_end = 0 THEN
                SET oneword = remaining_keywords;
                SET remaining_keywords = ''; -- 结束循环
            ELSE
                SET oneword = SUBSTRING(remaining_keywords, 1, keyword_end - 1);
                SET remaining_keywords = SUBSTRING(remaining_keywords, keyword_end + 1);
            END IF;

            -- 检查当前关键字的长度是否超过 10 个字符
            IF CHAR_LENGTH(oneword) > 10 THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Keywords limit exceeded';
            END IF;
        END WHILE;
END;

