create definer = root@localhost trigger after_book_insert
    after insert
    on book
    for each row
BEGIN
    -- 如果新插入的记录的 stock 值小于等于 1，执行插入操作
    IF NEW.stock <= 1 THEN
        INSERT INTO bookShortage (name, publish, sid, quantity, date)
        VALUES (NEW.name, NEW.publish, NEW.sid, 10, NOW());
    END IF;
END;

