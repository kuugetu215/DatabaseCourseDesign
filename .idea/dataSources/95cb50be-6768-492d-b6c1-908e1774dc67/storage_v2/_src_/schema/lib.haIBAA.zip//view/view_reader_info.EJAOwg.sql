create definer = root@localhost view view_reader_info as
select `lib`.`reader`.`id`            AS `ReaderID`,
       `lib`.`reader`.`uid`           AS `UserID`,
       `lib`.`reader`.`address`       AS `Address`,
       `lib`.`reader`.`balance`       AS `Balance`,
       `lib`.`reader`.`credit_rating` AS `CreditRating`
from `lib`.`reader`;

-- comment on column view_reader_info.ReaderID not supported: 读者编号

-- comment on column view_reader_info.UserID not supported: 用户编号

-- comment on column view_reader_info.Address not supported: 地址

-- comment on column view_reader_info.Balance not supported: 账户余额

-- comment on column view_reader_info.CreditRating not supported: 信用等级

