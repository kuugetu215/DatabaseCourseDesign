create definer = root@localhost view view_library_books as
select `lib`.`book`.`id`        AS `BookID`,
       `lib`.`book`.`name`      AS `BookName`,
       `lib`.`book`.`time`      AS `PublishTime`,
       `lib`.`book`.`price`     AS `Price`,
       `lib`.`book`.`publish`   AS `Publisher`,
       `lib`.`book`.`keyword`   AS `Keywords`,
       `lib`.`book`.`stock`     AS `Stock`,
       `lib`.`book`.`sid`       AS `Supplier`,
       `lib`.`book`.`series_id` AS `SeriesNumber`
from `lib`.`book`;

-- comment on column view_library_books.BookID not supported: 图书编号

-- comment on column view_library_books.BookName not supported: 书名

-- comment on column view_library_books.PublishTime not supported: 出版时间

-- comment on column view_library_books.Price not supported: 图书价格

-- comment on column view_library_books.Publisher not supported: 出版社

-- comment on column view_library_books.Keywords not supported: 关键字

-- comment on column view_library_books.Stock not supported: 库存数量

-- comment on column view_library_books.Supplier not supported: 供应商id

-- comment on column view_library_books.SeriesNumber not supported: 书籍系列编号

