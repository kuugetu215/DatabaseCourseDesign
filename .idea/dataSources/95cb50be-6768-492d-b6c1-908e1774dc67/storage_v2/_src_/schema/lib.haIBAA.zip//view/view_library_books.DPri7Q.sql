create definer = root@localhost view view_library_books as
select `lib`.`book`.`id`        AS `BookID`,
       `lib`.`book`.`name`      AS `BookName`,
       `lib`.`book`.`time`      AS `PublishTime`,
       `lib`.`book`.`price`     AS `Price`,
       `lib`.`book`.`publish`   AS `Publisher`,
       `lib`.`book`.`keyword`   AS `Keywords`,
       `lib`.`book`.`stock`     AS `Stock`,
       `lib`.`book`.`supplier`  AS `Supplier`,
       `lib`.`book`.`series_id` AS `SeriesId`
from `lib`.`book`;

