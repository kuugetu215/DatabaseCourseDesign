create definer = root@localhost view view_library_tickets as
select `lib`.`ticket`.`id`          AS `TicketID`,
       `lib`.`ticket`.`price`       AS `Price`,
       `lib`.`ticket`.`time`        AS `Time`,
       `lib`.`ticket`.`quantity`    AS `Quantity`,
       `lib`.`ticket`.`rid`         AS `ReaderID`,
       `lib`.`ticket`.`description` AS `Description`,
       `lib`.`ticket`.`address`     AS `Address`,
       `lib`.`ticket`.`state`       AS `State`
from `lib`.`ticket`;

