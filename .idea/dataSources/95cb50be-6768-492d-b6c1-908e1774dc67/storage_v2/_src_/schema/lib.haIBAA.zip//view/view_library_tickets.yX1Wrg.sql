create definer = root@localhost view view_library_tickets as
select `lib`.`ticket`.`id`          AS `TicketID`,
       `lib`.`ticket`.`price`       AS `Price`,
       `lib`.`ticket`.`quantity`    AS `Quantity`,
       `lib`.`ticket`.`rid`         AS `ReaderID`,
       `lib`.`ticket`.`description` AS `Description`,
       `lib`.`ticket`.`address`     AS `Address`,
       `lib`.`ticket`.`state`       AS `State`,
       `lib`.`ticket`.`date`        AS `Date`
from `lib`.`ticket`;

-- comment on column view_library_tickets.TicketID not supported: 订单编号

-- comment on column view_library_tickets.Price not supported: 价格

-- comment on column view_library_tickets.Quantity not supported: 数量

-- comment on column view_library_tickets.ReaderID not supported: 读者编号

-- comment on column view_library_tickets.Description not supported: 详细描述

-- comment on column view_library_tickets.Address not supported: 地址

-- comment on column view_library_tickets.State not supported: 状态

-- comment on column view_library_tickets.Date not supported: 记录时间

