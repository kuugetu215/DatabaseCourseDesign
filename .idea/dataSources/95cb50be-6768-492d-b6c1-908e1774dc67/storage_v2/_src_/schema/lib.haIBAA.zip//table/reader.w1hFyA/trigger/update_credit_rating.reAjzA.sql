create definer = root@localhost trigger update_credit_rating
    after update
    on reader
    for each row
BEGIN
UPDATE reader
SET credit_rating =
        CASE
            WHEN NEW.balance < 100 THEN 1
            WHEN NEW.balance >= 100 AND NEW.balance < 500 THEN 2
            WHEN NEW.balance >= 500 AND NEW.balance < 1000 THEN 3
            WHEN NEW.balance >= 1000 AND NEW.balance < 3000 THEN 4
            WHEN NEW.balance >= 3000 THEN 5
            END
WHERE id = NEW.id;
END;

